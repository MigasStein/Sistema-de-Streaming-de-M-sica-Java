
public class Musica {
	
	private String titulo;
	private String artista;
	private String genero;
	private int duracao;

	public Musica(String titulo, String artista, String genero, int duracao) {
		this.titulo = titulo;
		this.artista = artista;
		this.genero = genero;
		this.duracao = duracao;
	}

	public String getTitulo() {
		return titulo;
	}

	public String getArtista() {
		return artista;
	}

	public String getGenero() {
		return genero;
	}

	public String getDuracao() {
		int min = duracao / 60;
		int seg = duracao % 60;
		return min + ":" + (seg < 10 ? "0" + seg : seg);
	}

	@Override
	public String toString() {
		return "\"" + titulo + "\" - " + artista + " | " + getDuracao() + " | " + genero;
	}
}