
public class Playlistpublica extends Playlist {
	
	private String criador;

	public Playlistpublica(String nome, String criador) {
		super(nome);
		this.criador = criador;
	}

	@Override
	public void reproduzir() {
		if (total == 0) {
			System.out.println("Playlist vazia.\n");
			return;
		}
		System.out.println("▶  " + nome + " por " + criador + " [Pública]");
		System.out.println("   " + total + " música(s)\n");
		for (int i = 0; i < total; i++)
			System.out.println("   " + (i + 1) + ". " + musicas[i].getTitulo() + " - " + musicas[i].getArtista());
		System.out.println();
	}

	@Override
	public String getTipo() {
		return "Pública";
	}

	public String getCriador() {
		return criador;
	}
}