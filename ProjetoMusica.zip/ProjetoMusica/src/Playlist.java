
public abstract class Playlist {
	
	protected String nome;
	protected Musica[] musicas;
	protected int total;

	public Playlist(String nome) {
		this.nome = nome;
		this.musicas = new Musica[100];
		this.total = 0;
	}

	public void adicionarMusica(Musica m) {
		musicas[total++] = m;
		System.out.println("\"" + m.getTitulo() + "\" adicionada!\n");
	}

	public void removerMusica(int indice) {
		if (indice < 0 || indice >= total) {
			System.out.println("Índice inválido!\n");
			return;
		}
		System.out.println("\"" + musicas[indice].getTitulo() + "\" removida!\n");
		for (int i = indice; i < total - 1; i++)
			musicas[i] = musicas[i + 1];
		total--;
	}

	public void listar() {
		if (total == 0) {
			System.out.println("Playlist vazia.\n");
			return;
		}
		System.out.println("--- " + nome + " (" + total + " música(s)) ---");
		for (int i = 0; i < total; i++)
			System.out.println("  " + (i + 1) + ". " + musicas[i]);
		System.out.println();
	}

	public abstract void reproduzir();

	public abstract String getTipo();

	public String getNome() {
		return nome;
	}

	public int getTotal() {
		return total;
	}
}