
public class PlaylistPrivada extends Playlist {
	
	private String senha;
	private int tentativas;
	private static final int MAX_TENTATIVAS = 3;

	public PlaylistPrivada(String nome, String senha) {
		super(nome);
		this.senha = senha;
		this.tentativas = 0;
	}

	public boolean autenticar(String tentativa) {
		if (tentativas >= MAX_TENTATIVAS) {
			System.out.println("Playlist bloqueada por excesso de tentativas!\n");
			return false;
		}
		if (senha.equals(tentativa)) {
			tentativas = 0;
			return true;
		}
		tentativas++;
		int restantes = MAX_TENTATIVAS - tentativas;
		System.out.println("Senha incorreta! "
				+ (restantes > 0 ? restantes + " tentativa(s) restante(s)." : "Playlist bloqueada!") + "\n");
		return false;
	}

	public boolean estaBloqueada() {
		return tentativas >= MAX_TENTATIVAS;
	}

	@Override
	public void reproduzir() {
		if (total == 0) {
			System.out.println("Playlist vazia.\n");
			return;
		}
		System.out.println("▶  " + nome + " [Privada]");
		System.out.println("   " + total + " música(s)\n");
		for (int i = 0; i < total; i++)
			System.out.println("   " + (i + 1) + ". " + musicas[i].getTitulo() + " - " + musicas[i].getArtista());
		System.out.println();
	}

	@Override
	public String getTipo() {
		return "Privada";
	}
}