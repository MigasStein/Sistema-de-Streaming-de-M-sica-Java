import java.util.Scanner;

public class Main {
	
	static Scanner teclado = new Scanner(System.in);
	static Playlist[] playlists = new Playlist[50];
	static int totalPlaylists = 0;

	static void listarPlaylists() {
		if (totalPlaylists == 0) {
			System.out.println("Nenhuma playlist criada.\n");
			return;
		}
		System.out.println("--- Suas Playlists ---");
		for (int i = 0; i < totalPlaylists; i++) {
			String tipo = playlists[i].getTipo().equals("Pública") ? "[Pub]" : "[Pri]";
			System.out.println("  " + (i + 1) + ". " + tipo + " " + playlists[i].getNome() + " | "
					+ playlists[i].getTotal() + " música(s)");
		}
		System.out.println();
	}

	static int selecionarPlaylist() {
		listarPlaylists();
		if (totalPlaylists == 0)
			return -1;
		System.out.print("Número da playlist: ");
		int idx = Integer.parseInt(teclado.nextLine()) - 1;
		if (idx < 0 || idx >= totalPlaylists) {
			System.out.println("Índice inválido!\n");
			return -1;
		}
		return idx;
	}

	static void criarPlaylist() {
		System.out.print("Nome da playlist: ");
		String nome = teclado.nextLine();

		System.out.println("Tipo:  1. Pública   2. Privada");
		System.out.print("Escolha: ");
		int tipo = Integer.parseInt(teclado.nextLine());

		if (tipo == 1) {
			System.out.print("Seu nome: ");
			playlists[totalPlaylists++] = new Playlistpublica(nome, teclado.nextLine());
		} else {
			System.out.print("Crie uma senha: ");
			playlists[totalPlaylists++] = new PlaylistPrivada(nome, teclado.nextLine());
		}
		System.out.println("Playlist \"" + nome + "\" criada!\n");
	}

	static void adicionarMusica() {
		int idx = selecionarPlaylist();
		if (idx == -1)
			return;

		System.out.print("Título: ");
		String titulo = teclado.nextLine();
		System.out.print("Artista: ");
		String artista = teclado.nextLine();
		System.out.print("Gênero: ");
		String genero = teclado.nextLine();
		System.out.print("Duração (segundos): ");
		int dur = Integer.parseInt(teclado.nextLine());

		playlists[idx].adicionarMusica(new Musica(titulo, artista, genero, dur));
	}

	static void removerMusica() {
		int idx = selecionarPlaylist();
		if (idx == -1)
			return;

		playlists[idx].listar();
		if (playlists[idx].getTotal() == 0)
			return;

		System.out.print("Número da música para remover: ");
		playlists[idx].removerMusica(Integer.parseInt(teclado.nextLine()) - 1);
	}

	static void reproduzirPlaylist() {
		int idx = selecionarPlaylist();
		if (idx == -1)
			return;

		if (playlists[idx] instanceof PlaylistPrivada) {
			PlaylistPrivada pp = (PlaylistPrivada) playlists[idx];
			if (pp.estaBloqueada()) {
				System.out.println("Playlist bloqueada!\n");
				return;
			}
			System.out.print("Senha: ");
			if (!pp.autenticar(teclado.nextLine()))
				return;
		}

		playlists[idx].reproduzir();
	}

	static void verMusicas() {
		int idx = selecionarPlaylist();
		if (idx == -1)
			return;
		playlists[idx].listar();
	}

	// ── Main ─────────────────────────────────────────────────────

	public static void main(String[] args) {
		boolean rodando = true;
		System.out.println("=== StreamMusic ===\n");

		while (rodando) {
			System.out.println("1. Criar playlist");
			System.out.println("2. Adicionar música");
			System.out.println("3. Remover música");
			System.out.println("4. Ver músicas da playlist");
			System.out.println("5. Listar playlists");
			System.out.println("6. Reproduzir playlist");
			System.out.println("0. Sair");
			System.out.print("Escolha: ");

			int opcao = Integer.parseInt(teclado.nextLine());
			System.out.println();

			switch (opcao) {
			case 1:
				criarPlaylist();
				break;
			case 2:
				adicionarMusica();
				break;
			case 3:
				removerMusica();
				break;
			case 4:
				verMusicas();
				break;
			case 5:
				listarPlaylists();
				break;
			case 6:
				reproduzirPlaylist();
				break;
			case 0:
				rodando = false;
				System.out.println("Até mais!");
				break;
			default:
				System.out.println("Opção inválida!\n");
			}
		}
		teclado.close();
	}
}